let j = document.getElementById("joke1");
j.style.fontSize = "30px";
j.style.fontWeight = "Bold";
j.textContent = "Joke Displays Here";
let btn = document.getElementById("btn1");
btn.addEventListener("click", function() {
    let options = {
        method: "GET"
    };
    fetch("https://apis.ccbp.in/jokes/random", options)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            let str = JSON.stringify(data.value);
            j.textContent = str;
        });
});